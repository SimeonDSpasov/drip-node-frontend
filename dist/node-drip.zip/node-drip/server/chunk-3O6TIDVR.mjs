import './polyfills.server.mjs';
import{N as o,Nb as t,T as e,kc as a,lc as c,oa as i}from"./chunk-MZTDPML7.mjs";var f=class r{platformId=e(i);isServer=t(()=>c(this.platformId));isBrowser=t(()=>a(this.platformId));static \u0275fac=function(p){return new(p||r)};static \u0275prov=o({token:r,factory:r.\u0275fac,providedIn:"root"})};export{f as a};
